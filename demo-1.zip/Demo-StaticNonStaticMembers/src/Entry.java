import com.capgemini.Employee;
import com.capgemini.Manager;

public class Entry {

	public static void main(String[] args) {
//		int count = new Employee().getCount();
		
		int count = Employee.getCount();
		System.out.println(count);
		
		new Employee();
		new Employee();
		
		count = Employee.getCount();
		System.out.println(count);
		
		new Employee();
		Employee emp = new Employee("Vicky",35000);
		System.out.println("Employee details: "+ emp);
		
		Manager mgr = new Manager("Micky",45000);
//		System.out.println(mgr.getSalary());
		System.out.println("Manager details: "+ mgr );
		
		count = Employee.getCount();
		System.out.println(count);
		
	}
	
}
