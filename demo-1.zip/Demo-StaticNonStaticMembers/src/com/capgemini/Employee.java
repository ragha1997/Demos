package com.capgemini;

public class Employee {

	private int id;
	private String name;
	private double salary;

	private static int count;
	
	{
		System.out.println("inside instance initializer");
		id = ++count;
	}
	
	public Employee() {
		System.out.println("instantiating Employee");
//		id = ++count;
	}

	public Employee(String name, double salary) {
//		this();		// chaining constrctor
//		id = ++count;
		this.name = name;
		this.salary = salary;
	}

	static public int getCount(){
		
		return count;
	}


	static{
		System.out.println("inside static initializer");
		count = 99;
	}
	
	public double getSalary(){
		return salary;
	}
	
	public String toString(){
		return name + "/"+ getSalary();
	}
	
	
	
	
}
