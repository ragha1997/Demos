package com.capgemini;

public class Manager extends Employee {
	private double bonus = 10000;
//	private String name;
	
	public Manager(String name, double salary) {
/*		super.name = name;
		super.salary = salary;
*/		
		super(name, salary);
		System.out.println("instantiating Manager...");
	}
	
	public double getSalary(){
//		Employee e = new Employee();
		return super.getSalary() + bonus;
	}
	
	
}
