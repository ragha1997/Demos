import com.capgemini.ContractBasedEmployee;
import com.capgemini.Contractor;

public class Entry {
	public static void main(String[] args) {
		
		ContractBasedEmployee cbEmployee1 = new ContractBasedEmployee("Rajesh", 15);
		Contractor contractor1 = new Contractor("Suresh", 5000);
		
		contractor1.addCBEmployee(cbEmployee1);
		System.out.println("Wages "+ cbEmployee1.getSalary() + " & employed by" +
				cbEmployee1.getContractor().getName()
			);

		
		ContractBasedEmployee cbEmployee2 = new ContractBasedEmployee("Ramesh", 25);
		Contractor contractor2 = new Contractor("Kamalesh", 3000);

		contractor2.addCBEmployee(cbEmployee2);
		System.out.println("Wages "+ cbEmployee2.getSalary() + " & employed by" +
				cbEmployee2.getContractor().getName()
			);
		
		
		ContractBasedEmployee cbEmployee3 = new ContractBasedEmployee("Ramesh", 20);
		contractor2.addCBEmployee(cbEmployee3);
		System.out.println("Wages "+ cbEmployee3.getSalary() + " & employed by" +
					cbEmployee3.getContractor().getName()
				);
		
	}
}
