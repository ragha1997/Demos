package com.capgemini;

public class ContractBasedEmployee extends Employee {

	private int hours;

	public ContractBasedEmployee(String name, int hrs) {
		super(name);
		// TODO Auto-generated constructor stub
		this.hours = hrs;
	}

	private Contractor contractorRef;

	public void setContractor(Contractor contractorRef) {
		this.contractorRef = contractorRef;
	}
	
	public Contractor getContractor() {
		return contractorRef;
	}

	@Override
	public double getSalary() {
		return hours * contractorRef.getRate();
	}

}
