package com.capgemini;

public abstract class Employee {

	private String name;
	private double salary;
	private int id;
	

	
	abstract public double getSalary(); /*{
		return salary;
	}*/
	
	
	
	private static int count;

	{
		id = ++count;
	}

	public Employee(String name) {
		this.name = name;
	}

}
