package com.capgemini;

public class Contractor {

	private String name;
	private int rate;

	public int getRate() {
		return rate;
	}
	
	public String getName() {
		return name;
	}
	
	public Contractor(String name, int rate) {
		this.name = name;
		this.rate = rate;
	}

	private ContractBasedEmployee[] contractBasedEmployees = new ContractBasedEmployee[10];
	private int size;

	public boolean addCBEmployee(ContractBasedEmployee cbEmployee) {
		contractBasedEmployees[size] = cbEmployee;
		cbEmployee.setContractor(this);
		size++;
		return true;
	}

}
