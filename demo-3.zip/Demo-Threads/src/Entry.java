import com.capgemini.EvenNosThread;
import com.capgemini.OddNosThread;

public class Entry {

	public static void main(String[] args) {
		
		
		System.out.println("inside main()....");
		
		Thread t = new EvenNosThread();
//		t.run();
		t.start();
		
		Runnable target = new OddNosThread();
//		target.run();
		
		t = new Thread(target);
		t.start();
	} 
	
	
	
}
