import com.capgemini.beans.Bank;
import com.capgemini.utils.Teller;

public class Entry {

	public static void main(String[] args) {
		Bank bankRef = new Bank();

		Teller teller1 = new Teller(bankRef);
		new Thread(teller1).start();

		Teller teller2 = new Teller(bankRef);
		new Thread(teller2).start();

	}

}
