package com.capgemini.beans;

public class Bank {

	private Account[] accounts;
	
	public Bank() {
		accounts = new Account[5];
		
		for(int i = 0; i < accounts.length; i++){
			accounts[i] = new Account(5000, i);
		}
	}
	
	public boolean transferAmount(int toAcc, int fromAcc, double amount) throws InterruptedException{
		
		if(accounts[fromAcc].getBalance() > amount){
			accounts[fromAcc].withdraw(amount);
			accounts[toAcc].deposit(amount);
		}else{
			return false;
		}
		
		return true;
	}
	
	
	
	
	
	
}
