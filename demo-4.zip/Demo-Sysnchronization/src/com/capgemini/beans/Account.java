package com.capgemini.beans;

public class Account {

	private double balance;
	private int id;

	public Account(double balance, int id) {
		super();
		this.balance = balance;
		this.id = id;
	}

	boolean deposit(double amount) throws InterruptedException {
		double lBalance = this.balance;

		lBalance += amount;

		Thread.sleep(1000);

		this.balance = lBalance;

		return true;

	}

	
	public double getBalance() {
		return balance;
	}
	
	boolean withdraw(double amount) throws InterruptedException {
		double lBalance = this.balance;

		lBalance -= amount;

		Thread.sleep(1000);

		this.balance = lBalance;

		return true;

	}

}
