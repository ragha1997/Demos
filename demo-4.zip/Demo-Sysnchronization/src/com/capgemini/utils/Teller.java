package com.capgemini.utils;

import com.capgemini.beans.Bank;

public class Teller implements Runnable {

	private Bank bankRef;

	public Teller(Bank bankRef) {
		this.bankRef = bankRef;
	}

	@Override
	public void run() {
		try {
			performTransfer();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public boolean performTransfer() throws InterruptedException {
		
		for(int token = 0; token < 15; token++){
			int toAcc = (int)Math.ceil(Math.random() * 5);
			int fromAcc = (int)Math.ceil(Math.random() * 5);
			
			double amount = Math.ceil(Math.random() * 5000);
			
			bankRef.transferAmount(toAcc, fromAcc, amount);
			
		}
			
		return true;
		
	}

}
